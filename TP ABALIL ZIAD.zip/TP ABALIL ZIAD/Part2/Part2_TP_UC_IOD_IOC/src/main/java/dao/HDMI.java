package dao;

public interface HDMI {
    void print(byte[] data);
}
